#!/bin/bash
echo -e "your name is $1 and your surname is $2\n"
echo -e "$#"
echo -e "$@"
echo -e "$*"